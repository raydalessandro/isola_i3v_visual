# Brieffer per la scrittura — pacchetto integrazione

> **Scopo.** Aggiungere alla repo lo script `build_writing_brief.py` che genera, dato un `sid` (o tutte le 12 storie), un dossier autosufficiente per la scrittura della prosa finale di ciascuna storia de "L'Isola dei Tre Venti".
>
> **Costo:** zero token LLM. Lo script estrae meccanicamente da grafo, narrazioni fattuali, schede catalogo, prompt grok. Tutto il giudizio editoriale è già stato fatto a monte e fissato nel grafo.

---

## Cosa contiene questo pacchetto

```
brieffer_pkg/
├── README.md                          # questo file
├── scripts/
│   └── build_writing_brief.py         # lo script (~1100 righe)
└── skills/
    └── brieffer/
        └── SKILL.md                   # skill che spiega all'agente brieffer
                                       # cosa fare e come (procedura standard)
```

---

## Installazione

Da rootdir della repo `isola_i3v_visual`:

```bash
# Copia script nella cartella scripts/
cp brieffer_pkg/scripts/build_writing_brief.py scripts/

# Crea la cartella di output dei brief (se non esiste)
mkdir -p pipeline_narrativa/writing_briefs

# Copia la skill
mkdir -p skills/brieffer
cp brieffer_pkg/skills/brieffer/SKILL.md skills/brieffer/
```

---

## Uso

Da rootdir della repo:

```bash
# Genera brief per una sola storia
python3 scripts/build_writing_brief.py --story s01

# Genera tutti e 12 i brief (idempotente)
python3 scripts/build_writing_brief.py --all

# Output personalizzato
python3 scripts/build_writing_brief.py --story s01 --output-dir custom/path

# Da una repo diversa
python3 scripts/build_writing_brief.py --story s01 --repo-root /path/to/repo
```

I brief vengono scritti in `pipeline_narrativa/writing_briefs/sNN_writing_brief.md`.

---

## Cosa contiene un brief

13 sezioni, in ordine di lettura per l'agente prosa:

1. **Frontmatter operativo** — sid, titolo, ciclo, stagione, vento, lunghezza, registro
2. **Core narrativo** — premise / problem / threshold / resolution / palette emotiva
3. **Narrazione fattuale** integrale — referente di verità sui fatti
4. **10 hook visivi** (compatti) — per le 10 illustrazioni del libro
5. **Cast in scena** — voci, vincoli, frasi codificate (estratte automaticamente dalla narrazione fattuale), aspetto/comportamento da scheda + prompt grok
6. **Cornici del mondo** — le 2 cornici della storia, con processo di appartenenza
7. **Sentieri attraversati** — solo i dettagli stabili pertinenti a questa storia
   - 7-bis. Luoghi chiave (non sentieri)
   - 7-ter. Oggetti simbolo presenti
8. **Saluti dei gruppi** applicabili
9. **Formula ritornello** «che animale è» — con frasi pre-compilate
10. **Vincoli universali** — voci fratelli, narrator address, regole picture book, **PATTERN_AI_DA_BANDIRE_v1.md integrale**
11. **Quote tracker awareness** — Pattern A, TOK-TOK-TOK, frammenti pre-Vento, scene notturne, onomatopee firma
12. **Echi, callback, semi** — cosa la storia richiama e cosa lascia
13. **Istruzione operativa** all'agente prosa — modalità di lavoro collaborativa

---

## Come funziona — perché 0 token

Il brieffer è **puramente meccanico**. Non chiama LLM, non fa inferenza creativa.

Funziona perché tutto il giudizio editoriale è stato fatto in fasi precedenti:

- Le **narrazioni fattuali** delle 12 storie sono state scritte
- Gli **hook visivi** sono stati estesi a 10 per storia e validati
- Le **cornici del mondo** (24 totali) sono state distribuite e fissate nel grafo
- I **dettagli stabili dei sentieri Tier A** sono stati assegnati alle storie
- I **saluti** dei 5 gruppi sono nelle schede catalogo collettivi
- La **formula ritornello** è in `world_conventions.refrain_animal_identification`
- Le **frasi codificate** dei personaggi sono dentro le narrazioni fattuali tra `«…»`

Quando lanci lo script, lui:
1. Legge il grafo (`pipeline_narrativa/story_graph.json`)
2. Legge la narrazione fattuale (`pipeline_narrativa/narrazione_fattuale/sNN_*.md`)
3. Legge le schede catalogo dei personaggi/luoghi/oggetti in scena
4. Per le sezioni catalogo incomplete, fallback su `prompt_grok.md`
5. Compone il dossier markdown e lo scrive

**Risultato:** un brief di ~20-40k token, leggibile, autosufficiente, riproducibile.

---

## Token budget per brief (su saga corrente)

| Storia | Parole | Token stimati |
|---|---|---|
| s01 | ~16k | ~21k |
| s02-s05 | 14-19k | 19-25k |
| s06-s10 | 22-24k | 29-32k |
| s11 | ~32k | ~42k |
| s12 | ~29k | ~38k |

Il margine "extra" di s11 e s12 è dovuto al fatto che hanno più personaggi, più sentieri, più cornici. Le sezioni dense del catalogo (es. canone visivo Fiamma da prompt grok) sono presenti per intero, non troncate.

---

## Quando rilanciare lo script

Rilancia ogni volta che cambia qualcosa di rilevante per i brief:

- Modifiche al grafo (`story_graph.json`)
- Aggiornamenti alle schede catalogo personaggi/luoghi/oggetti
- Aggiornamenti ai prompt grok
- Modifiche alla narrazione fattuale

Lo script è **idempotente**: rilanciarlo sovrascrive i brief con la versione aggiornata. Nessun rischio di duplicazione.

---

## Cosa NON fa il brieffer

- **Non scrive prosa.** Quello è compito dell'agente prosa, che riceve il brief e produce la storia.
- **Non modifica il grafo.** Solo lettura.
- **Non chiama API LLM.** Zero token.
- **Non valida il contenuto.** Si fida del grafo come fonte canonica. Se il grafo ha errori, i brief li propagheranno.

---

## Estensione futura

Lo script è pensato per evolvere senza riscrittura totale. Aree dove può crescere:

- Aggiunta di sezioni nuove al brief (es. `world_processes_view.py` per intreccio dei processi A/B/C/D/E)
- Filtri sul brief (es. `--exclude-pattern-ai` per saltare la sezione integrale dei pattern banditi)
- Modalità "diff" che mostra cosa è cambiato dall'ultimo brief
- Output multipli (md + json) per consumo programmatico

---

## Riferimenti

- Documenti che hanno guidato la fase di design: `DOC_1` (formula ritornello), `DOC_2` (saluti), `DOC_3` (cornici), `DOC_4` (audit sentieri), `DOC_5` (index sentieri), `DOC_6` (mercato idee Tier A) — tutti in `cornice_mondo_pacchetto.zip` precedente
- Script affini nella repo: `scripts/write_hooks_to_graph.py`, `scripts/audit/audit_*.py`, `scripts/write_cornici_to_graph.py`
- Skill operativa: `skills/brieffer/SKILL.md`
