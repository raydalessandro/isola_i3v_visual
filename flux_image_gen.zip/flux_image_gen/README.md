# flux_image_gen

Modulo standalone per generazione immagini via **Flux** (fal.ai) con layer opzionale **ChatGPT** per l'enhancement del prompt.

## File

| File | Cosa fa |
|------|---------|
| `flux_image_gen.py` | `generate_image()` — Flux via fal.ai (4 tier, seed, reference image) |
| `openai_image_gen.py` | `generate_image()` + `edit_image()` — GPT Image via OpenAI API |
| `prompt_enhancer.py` | `enhance_prompt()` — riscrittura prompt via GPT-4o-mini (opzionale) |
| `example_generate.py` | Script di test: genera 1 immagine con seed fisso |

## Setup

```bash
cp .env.example .env
# compila FAL_KEY e/o OPENAI_API_KEY nel .env
pip install -r requirements.txt
python example_generate.py
```

## Uso — Flux

```python
from flux_image_gen import generate_image

result = generate_image(
    "A fox in a misty watercolor forest",
    tier="flux-kontext-pro",   # schnell / pro / kontext-pro / kontext-max
    size="1024x1536",
    seed=42,
    reference_image="ref.png", # opzionale, solo tier kontext
    output_path="out.png",
)
```

## Uso — OpenAI GPT Image

```python
from openai_image_gen import generate_image, edit_image

# text-to-image
result = generate_image(
    "A fox in a misty watercolor forest",
    size="1024x1536",
    quality="low",             # low = bozze ($0.016), high = produzione ($0.260)
    output_path="out.png",
)

# image-to-image con reference
result = edit_image(
    "Same character, now standing by a river at sunset",
    reference_image="page_01.png",
    input_fidelity="high",
    output_path="page_02.png",
)
```

## Dipendenze

Vedi `requirements.txt`. Richiede `FAL_KEY` per Flux, `OPENAI_API_KEY` per OpenAI.
