"""
prompt_enhancer.py — Layer opzionale ChatGPT per riscrivere/arricchire prompt prima di Flux.

Uso standalone:
    from prompt_enhancer import enhance_prompt
    enhanced = enhance_prompt("una volpe nella foresta")
    # → "Soft watercolor illustration of a fox standing in a misty forest..."

Integrato con flux_image_gen:
    from prompt_enhancer import enhance_prompt
    from flux_image_gen import generate_image

    enhanced = enhance_prompt(raw_prompt, style_context="watercolor children's book")
    generate_image(enhanced, tier="flux-kontext-pro", output_path="out.png")

Env vars richieste:
    OPENAI_API_KEY — chiave API OpenAI
"""

from __future__ import annotations

import os
from typing import Optional


# ---------------------------------------------------------------------------
# Prompt di sistema di default
# ---------------------------------------------------------------------------

_DEFAULT_SYSTEM_PROMPT = """You are a visual prompt specialist for AI image generation with Flux.
Your task is to rewrite raw scene descriptions into rich, detailed prompts optimized for Flux.

Rules:
- Expand visual details: lighting, textures, composition, color palette
- Keep character descriptions exact and specific (hair color, clothing, expression)
- Add artistic style only if not already present
- Output ONLY the enhanced prompt, no explanations
- Max 400 tokens
- Write in English"""


# ---------------------------------------------------------------------------
# API pubblica
# ---------------------------------------------------------------------------

def enhance_prompt(
    raw_prompt: str,
    *,
    style_context: Optional[str] = None,
    system_prompt: Optional[str] = None,
    model: str = "gpt-4o-mini",
    temperature: float = 0.7,
) -> str:
    """
    Arricchisce un prompt testuale via ChatGPT prima di passarlo a Flux.

    Args:
        raw_prompt:     Descrizione grezza della scena (es. "volpe nella foresta").
        style_context:  Stile visivo da mantenere (es. "watercolor children's book,
                        soft edges, warm palette"). Aggiunto al messaggio utente.
        system_prompt:  Override del system prompt. Se None, usa il default.
        model:          Modello OpenAI. Default: 'gpt-4o-mini' (economico + rapido).
        temperature:    Creatività. 0.7 bilanciato, 1.0 più vario.

    Returns:
        Prompt arricchito pronto per flux_image_gen.generate_image().

    Raises:
        RuntimeError: OPENAI_API_KEY mancante.
    """
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY non trovata. Setta la variabile d'ambiente "
            "o crea un file .env con OPENAI_API_KEY=<tua_chiave>."
        )

    from openai import OpenAI
    client = OpenAI(api_key=api_key)

    user_message = raw_prompt
    if style_context:
        user_message = f"Style: {style_context}\n\nScene: {raw_prompt}"

    response = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system_prompt or _DEFAULT_SYSTEM_PROMPT},
            {"role": "user", "content": user_message},
        ],
        temperature=temperature,
        max_tokens=500,
    )

    return response.choices[0].message.content.strip()


def enhance_batch(
    prompts: list[str],
    *,
    style_context: Optional[str] = None,
    model: str = "gpt-4o-mini",
) -> list[str]:
    """
    Arricchisce una lista di prompt (una chiamata API per prompt).

    Args:
        prompts:       Lista di prompt grezzi.
        style_context: Stile comune da applicare a tutti.
        model:         Modello OpenAI.

    Returns:
        Lista di prompt arricchiti, stesso ordine.
    """
    return [
        enhance_prompt(p, style_context=style_context, model=model)
        for p in prompts
    ]
