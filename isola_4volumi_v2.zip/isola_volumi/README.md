# L'Isola dei Tre Venti — README Pacchetto Editoriale
**Versione:** 1.0 — 2026-05-05

Questo pacchetto contiene tutto il materiale scritto per i 4 volumi della saga.
Le storie (S01–S12) si trovano nella repo GitHub separata.
Le presentazioni parziali per ciclo sono da assemblare (vedi Piano Editoriale).

---

## STRUTTURA DEI FILE IN QUESTO PACCHETTO

```
/
├── PIANO_EDITORIALE_4VOLUMI_v1.md     ← visione completa, ordine di lavoro
├── INTRODUZIONI_CICLI_v1.md           ← 4 introduzioni (una per volume)
├── LE_PORTE_v3.md                     ← 4 sezioni Porte (una per volume)
├── STATO_ZERO_E_SIGILLI_v1.md         ← 4 Stato Zero + 3 Sigilli di chiusura
│
└── _elementi_fissi/                   ← file originali, non modificare
    ├── CORNICI_Soglia_Congedo.docx    ← Soglia (tutti) + Congedo (solo Vol 4)
    ├── PRESENTAZIONE_isola_completa.docx  ← da dividere in 4 parziali
    ├── STATO_ZERO_originale.md        ← riferimento per il Vol 1
    └── LE_PORTE_cornice_narrativa_v2.md   ← cornice narrativa di riferimento
```

---

## STRUTTURA DI OGNI VOLUME — dove va ogni pezzo

### VOLUME 1 — Ciclo Δ — Inverno/Primavera — Distinguere
```
1. SOGLIA
   → CORNICI_Soglia_Congedo.docx (prima parte, "Prima di leggere")

2. INTRODUZIONE AL CICLO — Ciclo Δ
   → INTRODUZIONI_CICLI_v1.md § "VOLUME 1"

3. STATO ZERO
   → STATO_ZERO_E_SIGILLI_v1.md § "VOLUME 1"

4. STORIE
   → S01 — La Nebbia delle Montagne Gemelle  [repo GitHub]
   → S02                                      [repo GitHub]
   → S03                                      [repo GitHub]

5. PRESENTAZIONE PARZIALE — personaggi e luoghi del Ciclo Δ
   → da assemblare da PRESENTAZIONE_isola_completa.docx
   → [da fare]

6. LE PORTE — Vol 1
   → LE_PORTE_v3.md § "VOLUME 1 — Δ"
   → Bambini: Antoine (Il Piccolo Principe) + Arthur (Schopenhauer)

7. SIGILLO DI CHIUSURA Vol 1→2
   → STATO_ZERO_E_SIGILLI_v1.md § "SIGILLO Vol 1 → Vol 2"
```

---

### VOLUME 2 — Ciclo ⇄ — Primavera — Connettere
```
1. SOGLIA
   → CORNICI_Soglia_Congedo.docx (prima parte, identica)

2. INTRODUZIONE AL CICLO — Ciclo ⇄
   → INTRODUZIONI_CICLI_v1.md § "VOLUME 2"

3. STATO ZERO
   → STATO_ZERO_E_SIGILLI_v1.md § "VOLUME 2"

4. STORIE
   → S04  [repo GitHub]
   → S05  [repo GitHub]
   → S06  [repo GitHub]

5. PRESENTAZIONE PARZIALE — personaggi e luoghi del Ciclo ⇄
   → da assemblare da PRESENTAZIONE_isola_completa.docx
   → [da fare]

6. LE PORTE — Vol 2
   → LE_PORTE_v3.md § "VOLUME 2 — ⇄"
   → Bambini: Publio (Ovidio, Metamorfosi)

7. SIGILLO DI CHIUSURA Vol 2→3
   → STATO_ZERO_E_SIGILLI_v1.md § "SIGILLO Vol 2 → Vol 3"
```

---

### VOLUME 3 — Ciclo ⟳ — Estate/Autunno — Cambiare
```
1. SOGLIA
   → CORNICI_Soglia_Congedo.docx (prima parte, identica)

2. INTRODUZIONE AL CICLO — Ciclo ⟳
   → INTRODUZIONI_CICLI_v1.md § "VOLUME 3"

3. STATO ZERO
   → STATO_ZERO_E_SIGILLI_v1.md § "VOLUME 3"

4. STORIE
   → S07  [repo GitHub]
   → S08  [repo GitHub]
   → S09  [repo GitHub]

5. PRESENTAZIONE PARZIALE — personaggi e luoghi del Ciclo ⟳
   → da assemblare da PRESENTAZIONE_isola_completa.docx
   → [da fare]

6. LE PORTE — Vol 3
   → LE_PORTE_v3.md § "VOLUME 3 — ⟳"
   → Bambini: Franz (Kafka, Il Processo) + Johann (Goethe, Affinità Elettive)
   → Nota: rimando al parallelo Ovidio/Kafka sul titolo Metamorfosi

7. SIGILLO DI CHIUSURA Vol 3→4
   → STATO_ZERO_E_SIGILLI_v1.md § "SIGILLO Vol 3 → Vol 4"
```

---

### VOLUME 4 — Integrazione — Autunno — Tutti e tre i venti
```
1. SOGLIA
   → CORNICI_Soglia_Congedo.docx (prima parte, identica)

2. INTRODUZIONE AL CICLO — Integrazione
   → INTRODUZIONI_CICLI_v1.md § "VOLUME 4"

3. STATO ZERO
   → STATO_ZERO_E_SIGILLI_v1.md § "VOLUME 4"

4. STORIE
   → S10  [repo GitHub]
   → S11  [repo GitHub]
   → S12  [repo GitHub]

5. PRESENTAZIONE PARZIALE — personaggi e luoghi del Ciclo Integrazione
   → da assemblare da PRESENTAZIONE_isola_completa.docx
   → [da fare]

6. LE PORTE — Vol 4
   → LE_PORTE_v3.md § "VOLUME 4 — Integrazione"
   → Bambini: Egizio senza nome + Platone (Timeo) + Daniele (Migliorino)

7. CONGEDO
   → CORNICI_Soglia_Congedo.docx (seconda parte)
   → [solo in questo volume]

   [nessun Sigillo — il Volume 4 è la chiusura]
```

---

## DA COMPLETARE

| Elemento | Stato | Note |
|----------|-------|------|
| Presentazione parziale Vol 1 | ✅ fatto | Fiamma, Grunto, Rovo, Stria, Mèmolo+Pun |
| Presentazione parziale Vol 2 | ✅ fatto | Fiamma, Rovo, Stria, Mèmolo+Pun, Nodo, Liù, Salvia, Zolla |
| Presentazione parziale Vol 3 | ✅ fatto | Fiamma, Bartolo, Rovo, Stria, Mèmolo+Pun, Nodo, Liù, Zolla |
| Presentazione parziale Vol 4 | ✅ fatto | Tutti i quartieri + quasi tutti i personaggi |
| Revisione morale Introduzioni | ⬜ da fare | Ray: "un po' troppa morale, sistemo alla fine" |

---

## NOTE FINALI

- Le storie S01–S12 vengono dalla repo GitHub: `raydalessandro/isola_i3v_visual`
- I writing brief per ogni storia sono in `pipeline_narrativa/writing_briefs/`
- Le presentazioni parziali si assemblano estraendo dalla Presentazione completa
  solo i personaggi e luoghi che compaiono nelle storie del ciclo corrispondente
- Il framework EAR non è mai nominato in nessun file di questo pacchetto
