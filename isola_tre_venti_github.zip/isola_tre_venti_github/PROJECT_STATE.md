# PROJECT_STATE — Snapshot al 2026-04-24

Documento riassuntivo di **dove siamo oggi**. Per il dettaglio storico vedi `cartografia_tecnica/CHANGELOG.md`.

---

## Cosa abbiamo chiuso oggi (sessione 2026-04-24)

Sessione dedicata alla **nascita e costruzione della cartografia tecnica**, da zero a v0.5. Cinque release incrementali:

| Versione | Cosa introduce |
|----------|----------------|
| **v0.1** | Bootstrap: struttura directory, convenzioni base, contorno isola, Fiume preliminare come anello chiuso, 4 centroidi quartieri, 18 feature |
| **v0.2** | Risolta fisica del Fiume (Variante C: due bracci asimmetrici, Sorgente a nord, Bocca a sud). Allargata rete sentieri da grafo storie. 46 feature. |
| **v0.3** | Fiume spezzato in sotto-tratti per agganciare punti canonici. Sorgente da falda (non da ruscelli). Posizionamento completo: Piazza, Orti a 3 anelli, Foresta polygon, Pascoli, quartieri polygon, edifici Villaggio e Quartiere Fuoco. 74 feature. |
| **v0.4** | Backward-compatibility totale con grafo storie v0.6.0 (34/34 ID coperti via alias/aggregate/parent). Strade canoniche estratte dalle 8 storie. Nuovi landmark: Pozza dei Pascoli (S2), Noce della Scuola (S8), I Due Massi (S7), Zona di lavoro Salvia (S4). 83 feature. |
| **v0.5** | Urbanistica completa e navigabile. 18 sentieri nuovi per raggiungibilità di tutti gli edifici. Visualizzatore web Google Maps-style (ricerca, pannello dettaglio, filtri, navigazione parent/children). 103 feature, 36 sentieri. |

---

## Stato attuale

- **Cartografia:** `cartografia_tecnica/geo/island.geojson` v0.5 — 103 feature.
- **Grafo storie:** `pipeline_narrativa/story_graph.json` v0.6.0 — 8 storie S1-S8 completate.
- **Documenti progetto:** corpus canonico completo in `pipeline_narrativa/documenti_progetto/` (Bible, Glossario, voce, pattern AI da bandire, archi 12 storie, EAR framework, ecc.).
- **Apparato:** v0.2, trattato come giacimento di estrazione non autoritativo (vedi disclaimer).
- **Backward-compatibility grafo ↔ cartografia:** 100%.

---

## Decisioni chiave fissate oggi

1. **Fiume a Variante C:** due bracci asimmetrici (Ovest stretto e veloce, Est ampio e lento) che si uniscono a Sorgente nord e Bocca sud. Fisicamente coerente con S7 (zattera).
2. **Sorgente da falda profonda**, non da ruscelli superficiali. Lascia flessibilità narrativa su ruscelli stagionali.
3. **Sotto-tratti del Fiume** spezzati quando un punto narrativo ha peso canonico (es. Stretta dei Due Massi da S7).
4. **Backward-compatibility ID via aliases** (es. `villaggio_centrale` → `piazza_villaggio`) **e feature aggregate** (es. `fiume_che_gira` come MultiLineString con 6 children). Nessuna rottura del grafo storie.
5. **Isolamento cartografia/narrativa:** cartografia non modifica mai il corpus narrativo. Se emergono incoerenze, si segnalano, non si risolvono in autonomia.
6. **Urbanistica completa** anche oltre quella battuta dalle storie (sentieri costieri, ring road Quartiere Fuoco, viottoli Piazza). Tutto inferito è `provvisorio`.

---

## Prossimi passi naturali

### Per Ray (priorità)

1. Caricare questo repository su GitHub.
2. Configurare agente IA (Claude Agent SDK via Anthropic API) per lavorare sul repo.
3. Testare il visualizzatore web e feedback estetica/funzionalità.
4. Aggiornare `pipeline_narrativa/story_graph.json` quando arrivano nuove storie da altro autore.

### Per l'agente IA (quando Ray attiva il workflow)

1. Verificare backward-compat dopo ogni update del grafo.
2. Estrarre riferimenti geografici dalle nuove storie S9-S12.
3. Proporre feature nuove o aggiornamenti `status`.
4. Mantenere CHANGELOG aggiornato.

### Iterazione futura (non urgente)

- **Schede luogo dettagliate** — compilare `luoghi/<quartiere>/<id>.md` a partire dai luoghi-chiave (Forno, Albero Vecchio, Grotta di Grunto, Casa di Amo, Pontile).
- **Fix posizioni Vie** — fare in modo che le Vie principali si fermino al bordo della Piazza, non al centro esatto.
- **Pipeline immagini** — quando sarà ora, prompt BFL pescano automaticamente da schede + GeoJSON per garantire coerenza visiva cross-scena.
- **Mondo digitale** — base dati strutturata pronta per eventuale sito esplorabile/app.

---

## Cosa NON abbiamo toccato (volutamente)

- **Bible, Glossario, voce, pattern_ai_da_bandire, ARCHI 12 storie:** corpus narrativo intatto, solo referenziato.
- **Grafo storie:** Ray lo aggiorna manualmente. Cartografia lo legge ma non lo scrive.
- **Apparato v0.2:** pre-esistente alla cartografia, trattato come giacimento non autoritativo. Ray lo riscriverà a valle.
- **Scrittura prosa storie:** fuori dal perimetro cartografia. Gestito da Ray + altro autore.

---

## Contatti file-chiave

- **README principale:** `README.md` (radice repo)
- **Istruzioni per agenti IA:** `AGENT_INSTRUCTIONS.md`
- **Questo documento:** `PROJECT_STATE.md`
- **Storia cartografia:** `cartografia_tecnica/CHANGELOG.md`
- **Architettura cartografia:** `cartografia_tecnica/README.md`
- **Fonte di verità geometrica:** `cartografia_tecnica/geo/island.geojson`
- **Visualizzatore:** `cartografia_tecnica/geo/viewer/index.html` (doppio click)
- **Utility verifica:** `cartografia_tecnica/verifica_luogo.py`

---

**Buon lavoro.**
