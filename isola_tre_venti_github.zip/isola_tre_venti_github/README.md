# Isola dei Tre Venti — Cartografia Tecnica

**Repository GitHub per sviluppo cartografia tecnica del progetto "L'Isola dei Tre Venti".**

Saga di 12 storie illustrate per bambini 4-10 anni scritta da Ray in italiano. Tre fratelli (Gabriel, Elias, Noah) su un'isola con tre venti-spiriti e quattro quartieri.

---

## 1. Scopo di questo repository

Questa è la **cartografia tecnica canonica** dell'Isola. Directory parallela e isolata rispetto alla pipeline narrativa principale.

**Cosa contiene:**
- `cartografia_tecnica/` — GeoJSON, schede luogo, convenzioni, visualizzatore web. **Questo è su cui si lavora.**
- `pipeline_narrativa/` — grafo storie, documenti progetto (Bible, Glossario, voce, ecc.). **Input read-only.**

**A cosa serve la cartografia tecnica:**
1. Alimentare con coerenza la pipeline di generazione immagini (BFL FLUX, Grok).
2. Validare geograficamente nuove storie (confronto punti narrativi vs cartografia canonica).
3. Fornire la base dati per un futuro mondo digitale dell'Isola.

**NON serve per il lettore finale** — il lettore vedrà solo illustrazioni e storie, non vedrà mai questo.

## 2. Stato attuale

- **Cartografia:** v0.5, 103 feature (60 canonico, 41 provvisorio, 2 stub). Rete stradale completa (36 sentieri), tutti gli edifici canonici raggiungibili.
- **Grafo storie:** v0.6.0, 8 storie completate (S1-S8). S9-S12 in scrittura da altro autore.
- **Backward-compatibility grafo ↔ cartografia:** 100% (34/34 ID cartografici coperti).

## 3. Come iniziare

### Per navigare la mappa

Apri in browser:

```
cartografia_tecnica/geo/viewer/index.html
```

Doppio click sul file. Nessuna dipendenza da installare (Leaflet via CDN).

Funzionalità: ricerca per nome/ID/alias, pannello dettaglio al click, filtri per categoria/quartiere/status, navigazione parent/children.

### Per verificare coerenza geografica

```bash
cd cartografia_tecnica/
python3 verifica_luogo.py --id due_massi           # info su luogo canonico
python3 verifica_luogo.py --id villaggio_centrale  # risolve alias
python3 verifica_luogo.py --id fiume_che_gira      # feature aggregata
python3 verifica_luogo.py --coord 3100 5500        # cosa c'è in un punto
python3 verifica_luogo.py --geo 18.0 34.5          # coord geografiche
```

### Per leggere il contesto narrativo

- `pipeline_narrativa/documenti_progetto/ISOLA_TRE_VENTI_BIBLE_v2.md` — la Bible del mondo.
- `pipeline_narrativa/documenti_progetto/GLOSSARIO_ISOLA.md` — catalogo nomi.
- `pipeline_narrativa/story_graph.json` — grafo storie v0.6.0 (aggiornato da Ray).
- `pipeline_narrativa/documenti_progetto/ARCHI_12_STORIE_v1_1.md` — mappa 12 archi narrativi.

## 4. Struttura repository

```
/
├── README.md                        <- questo file
├── AGENT_INSTRUCTIONS.md            <- istruzioni per agenti IA
├── .gitignore
│
├── cartografia_tecnica/             <-- CORE: si lavora qui
│   ├── README.md                    <- architettura e regole di isolamento
│   ├── CHANGELOG.md                 <- storia versioni v0.1 → v0.5
│   ├── verifica_luogo.py            <- utility validazione
│   │
│   ├── geo/
│   │   ├── island.geojson           <- FONTE DI VERITÀ GEOMETRICA
│   │   ├── anteprima_v0_5.png       <- preview statica
│   │   └── viewer/
│   │       ├── index.html           <- visualizzatore Google Maps-style
│   │       └── style.css
│   │
│   ├── luoghi/
│   │   └── _template_scheda.md      <- template per schede luogo dettagliate
│   │
│   └── convenzioni/
│       ├── sistema_coordinate.md    <- WGS84, ancoraggio Mediterraneo
│       ├── scala_e_proporzioni.md   <- dimensioni canoniche
│       ├── convenzioni_id.md        <- snake_case italiano
│       └── orientamenti_venti.md    <- venti, orientamenti edifici
│
└── pipeline_narrativa/              <-- INPUT: non modificare dalla cartografia
    ├── story_graph.json             <- v0.6.0, aggiornato da Ray
    │
    ├── documenti_progetto/          <- corpus canonico narrativo
    │   ├── ISOLA_TRE_VENTI_BIBLE_v2.md
    │   ├── GLOSSARIO_ISOLA.md
    │   ├── ARCHI_12_STORIE_v1_1.md
    │   ├── VOCE_AUTORE_ESTRATTA_v1_1.md
    │   ├── CARTA_VOCE_v1_2.md
    │   ├── PATTERN_AI_DA_BANDIRE_v1.md
    │   ├── MITI_FONDATORI_BREVI_v1.md
    │   ├── EAR_KERNEL_AILA_v1_0.md
    │   ├── EAR_PERSONAGGI_Manuale_Completo.txt
    │   ├── EAR_PERSONAGGI_Lezioni_Apprese.txt
    │   ├── APPENDIX_STYLISTIC_DERIVATION_v1.md
    │   ├── METODO_REVISIONE_B3_v1_1.md
    │   ├── RIFERIMENTI_OPERATIVI.md
    │   ├── PROGETTO_INDICE_v1_5.md
    │   └── STORIE_SCHEMA_v1_1.md    (SUPERSEDED — riferimento storico)
    │
    └── apparato_v0_2_disclaimer/    <- giacimento estrazione, NON autoritativo
        ├── ISOLA_APPARATO_PUBBLICO.md
        └── ISOLA_APPARATO_TECNICO.md
```

## 5. Principi di isolamento

La cartografia è **parallela** alla pipeline narrativa. Regole:

- Il **corpus narrativo** (Bible, grafo storie, apparato, manoscritti) **non viene modificato** dalla cartografia. Se la cartografia rileva incoerenze, le segnala — la risoluzione è decisione narrativa separata.
- La **cartografia non è autoritativa** sul canone narrativo primario (caratteri, seeds, debt, Pattern A, voce). Quella autorità vive nella pipeline narrativa.
- La **cartografia è autoritativa** sul canone fisico e urbanistico (coordinate, dimensioni, orientamenti, materiali, transizioni spaziali).
- Quando le autorità si sovrappongono, **Bible + grafo vincono**; la cartografia dettaglia senza contraddire.

## 6. Workflow di aggiornamento

**Quando Ray aggiorna il grafo** (nuova storia S9-S12):
1. Sostituisce `pipeline_narrativa/story_graph.json` con la versione nuova.
2. L'agente IA estrae riferimenti geografici dalla storia nuova.
3. Confronta con `cartografia_tecnica/geo/island.geojson`.
4. Propone: (a) nuove feature se emergono punti/sentieri nuovi, (b) segnalazioni se ci sono incoerenze, (c) aggiornamenti `status` (es. da provvisorio a canonico).
5. Commit in un branch separato, review umana, merge.

**Quando si compila una scheda luogo dettagliata:**
1. Duplicare `cartografia_tecnica/luoghi/_template_scheda.md` in `luoghi/<quartiere>/<id>.md`.
2. Compilare sezioni applicabili (le altre si omettono).
3. Aggiornare `status` nella feature GeoJSON corrispondente se passa da `provvisorio` a `canonico`.
4. Annotare in `CHANGELOG.md`.

**Quando si aggiunge una feature geografica nuova:**
1. Scegliere ID in `snake_case` italiano (vedi `convenzioni/convenzioni_id.md`).
2. Aggiungere feature al GeoJSON con `status` appropriato.
3. Verificare con `verifica_luogo.py` che non ci siano conflitti.
4. Se possibile, rigenerare anteprima statica.

## 7. Versioning

SemVer per la cartografia:
- **MAJOR** (v1.0.0): breaking schema change, rimozione campi canonici.
- **MINOR** (v0.X.0): aggiunta significativa di feature o sentieri, nuove storie mappate.
- **PATCH** (v0.X.Y): fix puntuali, correzioni posizioni, typo.

Tag Git e release consigliati a ogni MINOR bump.

## 8. Contatti e responsabilità

- **Autore narrativo e proprietario progetto:** Ray.
- **Manutentore grafo storie:** Ray (altro autore scrive alcune storie sotto sua supervisione).
- **Manutentore cartografia:** agente IA via Claude Agent SDK / Anthropic API, con Ray come review/commit authority.

## 9. Licenza

Progetto personale/editoriale di Ray. Non ancora pubblicato. Da definire.

---

**Ultimo aggiornamento:** 2026-04-24
**Versione cartografia:** v0.5
**Versione grafo storie:** v0.6.0
