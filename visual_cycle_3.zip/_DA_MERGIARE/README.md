# 📦 _DA_MERGIARE — Pacchetto pronto per la repo `isola_i3v_visual`

**Data:** 2026-04-29
**Versione pacchetto:** v1.3 (sessione luoghi Quartiere d'Acqua + Forno + Orti del Cerchio + Gabriel parziale)

---

## ✅ Cosa contiene

Schede pronte per essere copiate dentro la repo `isola_i3v_visual/visual/`. La struttura cartelle è già quella corretta della repo — **basta copiare** `visual/` di questa zip dentro `isola_i3v_visual/visual/` (sovrascrivendo le schede vecchie).

### 📍 Luoghi nuovi (8 schede)

**Quartiere d'Acqua** (5 luoghi, primo blocco completo):
- `pontile_bocca/` — ✅ scheda complessa con 3 blocchi LOCATION (esterno + interno capanna + annessi barca/ponte)
- `bocca/` — ✅ scheda con 1 blocco LOCATION (esterno river_mouth)
- `spiaggia_conchiglie/` — ✅ scheda con 1 blocco LOCATION (esterno beach)
- `casa_amo/` — ✅ scheda complessa con 3 blocchi LOCATION (esterno + interno + scaletta)
- `case_basse_pescatori/` — ✅ scheda con 1 blocco LOCATION (esterno cluster)

**Quartiere di Fuoco** (1 luogo):
- `forno/` — ✅ scheda complessa con 3 blocchi LOCATION (esterno + interno + cortile retro)

**Quartiere di Terra** (1 luogo):
- `orti_del_cerchio/` — ✅ scheda con 1 blocco LOCATION (esterno fields)

Tutte le schede:
- Hanno frontmatter YAML valido (parsato con yaml Python)
- Mantengono i metadati cartografici originali della repo
- Includono "Riferimenti puntuali" con citazioni dirette dalle fonti canoniche
- Includono "Derivazioni autoriali" trasparenti (cosa è stato derivato e perché)
- Hanno sezione "Disallineamenti / domande aperte" per validazione

### 👥 Personaggi (3 schede)

**Validati e pronti**:
- `personaggi/individuali/maggiori/fiamma/` — ✅ STANDARD, 4 immagini canoniche
- `personaggi/individuali/maggiori/bartolo/` — ✅ STANDARD, 4 immagini canoniche

**Parziale, DA VALIDARE da Ray** (rischio scelte sensibili sui figli reali):
- `personaggi/individuali/bambini/gabriel/scheda.md` — ⚠️ **DA REVISIONARE**
  - Scelte tecniche di pipeline complete (anchor di scala, modalità, palette firma)
  - **Tratti fisici lasciati come "DA CONFERMARE"** (capelli, occhi, età narrativa) — sezione "Disallineamenti" segnala chiaramente cosa va validato
  - **Outfit canonico** proposto (camicia/maglia blu scuro + sciarpa/bandana viola scuro) derivato dalla palette §6 Bible
  - Manca prompt_grok.md e descrizione_narrativa_social.md — verranno completati una volta validati i tratti

### 🧪 Oggetti (1 scheda)

- `oggetti/grembiule_fiamma/` — scheda OK, prompt da rigenerare con stylesheet validata

---

## 📋 Cosa fare per il merge

### Passo 1: backup veloce (consigliato)
```bash
cd ~/isola_i3v_visual
git checkout -b feature/visual-cycle-3
git add . && git commit -m "snapshot pre-merge"
```

### Passo 2: copia il contenuto di questa zip
Copia `_DA_MERGIARE/visual/` dentro `isola_i3v_visual/visual/`, sovrascrivendo i file con stesso path.

```bash
cp -r _DA_MERGIARE/visual/* ~/isola_i3v_visual/visual/
```

### Passo 3: copia anche `_visual_pipeline/` (è sorella di `visual/`)
```bash
cp -r _visual_pipeline ~/isola_i3v_visual/
```

### Passo 4: verifica
```bash
cd ~/isola_i3v_visual
python audit_2_schema.py  # se hai aggiornato la cartografia, altrimenti facoltativo
git status
git diff visual/luoghi/quartiere_acqua/pontile_bocca/scheda.md
```

### Passo 5: aggiungi le immagini canoniche di Fiamma e Bartolo
Nelle rispettive `immagini/`:
```
visual/personaggi/individuali/maggiori/fiamma/immagini/
visual/personaggi/individuali/maggiori/bartolo/immagini/
```

### Passo 6: validazione finale Gabriel
Apri `visual/personaggi/individuali/bambini/gabriel/scheda.md` e verifica:
- **Età narrativa nelle storie**: ho proposto 6-7 anni. Confermare o cambiare.
- **Colore capelli**: ho proposto "castani scuri o castano-chiari". Confermare o specificare colore preciso.
- **Colore occhi**: ho proposto "castani scuri / marrone profondo". Confermare o cambiare.
- **Aderenza ai figli reali**: scegliere se vuoi tratti specifici dei tuoi figli o se i tratti derivati canonicamente sono OK.

Una volta validato, fammi sapere e completo `prompt_grok.md` e `descrizione_narrativa_social.md` di Gabriel, poi passiamo a Elias e Noah.

---

## 🗺️ Mappa dei file in questa zip

```
_DA_MERGIARE/
├── README.md (questo file)
└── visual/
    ├── luoghi/
    │   ├── quartiere_acqua/
    │   │   ├── bocca/
    │   │   │   ├── scheda.md
    │   │   │   └── descrizione_narrativa_social.md
    │   │   ├── casa_amo/
    │   │   │   ├── scheda.md
    │   │   │   └── descrizione_narrativa_social.md
    │   │   ├── case_basse_pescatori/
    │   │   │   ├── scheda.md
    │   │   │   └── descrizione_narrativa_social.md
    │   │   ├── pontile_bocca/
    │   │   │   ├── scheda.md
    │   │   │   └── descrizione_narrativa_social.md
    │   │   └── spiaggia_conchiglie/
    │   │       ├── scheda.md
    │   │       └── descrizione_narrativa_social.md
    │   ├── quartiere_fuoco/
    │   │   └── forno/
    │   │       ├── scheda.md
    │   │       └── descrizione_narrativa_social.md
    │   └── quartiere_terra/
    │       └── orti_del_cerchio/
    │           ├── scheda.md
    │           └── descrizione_narrativa_social.md
    ├── oggetti/
    │   └── grembiule_fiamma/
    │       ├── scheda.md
    │       ├── prompt_grok.md
    │       └── descrizione_narrativa_social.md
    └── personaggi/
        └── individuali/
            ├── bambini/
            │   └── gabriel/
            │       └── scheda.md  ← ⚠️ DA VALIDARE
            └── maggiori/
                ├── bartolo/
                │   ├── scheda.md
                │   ├── prompt_grok.md
                │   └── descrizione_narrativa_social.md
                └── fiamma/
                    ├── scheda.md
                    ├── prompt_grok.md
                    └── descrizione_narrativa_social.md

_visual_pipeline/   ← cartella sorella di visual/, da copiare a livello root della repo
└── (vedi README dentro)
```

---

## 📊 Bilancio sessione

**Schede luoghi totali completate**: 7 (5 Quartiere d'Acqua + 1 Forno + 1 Orti)
**Schede personaggi**: 2 validate (Fiamma, Bartolo) + 1 parziale (Gabriel)
**Pattern luogo-complesso testato**: 3 volte (Forno, Pontile, Casa Amo) — ✅ pipeline luoghi robusta
**Pattern luogo-semplice testato**: 4 volte (Bocca, Spiaggia, Case Basse, Orti) — ✅ pipeline robusta
**Tutti i file**: parseable YAML, UTF-8, blocchi codice bilanciati ✅

**Prossimi passi suggeriti** (per la prossima sessione):
1. Validare tratti Gabriel → completare prompt_grok + descrizione_narrativa_social
2. Fare Elias (0.85 GU) e Noah (0.65 GU) seguendo lo stesso pattern
3. Continuare con **Quartiere d'Aria** (Pascoli Alti, Roccia Alta, Montagne Gemelle, Burrone, grotta di Grunto) — blocco coerente
4. Personaggi rimanenti: Rovo, Stria, Mèmolo, Grunto, Salvia, Nodo, Amo, Zolla
5. Cuccioli (Pun, Toba, Bru, Cardo, Liù)
6. Collettivi (Coltivatori, Mantenitori, Camminanti, Pastori, Vecchie del Mercato, Pescatori del Pontile)
